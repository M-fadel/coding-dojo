from django.apps import AppConfig


class BeltappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'beltApp'
