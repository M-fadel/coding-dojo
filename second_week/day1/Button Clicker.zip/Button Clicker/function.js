function logout(element){

    // console.log("hello there ;)")
    
    element.innerText = "logout";
}   
function disappear(element){
element.remove( );

}