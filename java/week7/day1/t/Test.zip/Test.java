public class Test {

    public static void main(String[] args) {
        System.out.println("My name is Mohammed");
        System.out.println("I am is 25 years old");
        System.out.println("my home town is Jeddah, KSA");
        
    }
}
