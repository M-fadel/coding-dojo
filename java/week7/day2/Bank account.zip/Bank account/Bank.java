public class Bank {
    private double balance;
    private double savings;
    private static int Accounts;
    private static double Total;
    public Bank() {
        this.Accounts++;
    }
    public double getBalance() {
        return balance;
    }
    public double getSavings() {
        return savings;
    }
    public void setBalance(double balance) {
        this.balance = balance;
        this.Total += balance;
    }
    public void setSavings(double savings) {
        this.savings = savings;
        this.Total += savings;
    }

    public void displayTotal() {
        System.out.println("your total money is " + this.Total);
    }
    
    public void  withdrawbalance(double amount) {
        if (this.balance - amount <= 0) {
            System.out.println("go find a better job");
        }else{
            setBalance((-1*amount));
        }
            
    }
}
